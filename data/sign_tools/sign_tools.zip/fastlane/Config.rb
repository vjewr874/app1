module Config

    CERT = '../../cert/'
    MOVILE = '../../uploads/ios_mobileprovision/'

	HOST = '127.0.0.1'
    DBNAME = 'xffenfa'
    USER = 'xffenfa'
    PASSWORD = 'Tj5sXWZEG57WY3YK'
    CHARSET = 'utf8mb4'

end